/* =============================================
   EcoScan — Main App JavaScript
   AI-powered plastic pollution awareness app
   ============================================= */

// ===== STATE =====
const state = {
  user: null,
  points: 0,
  scansCount: 0,
  plasticAvoided: 0,
  streakDays: 0,
  currentTab: 'home',
  scanHistory: [],
  joinedEvents: new Set(),
  likedStories: new Set(),
  challengeProgress: { plasticFree: 5, bagmati: 1, scan10: 7 },
};

// ===== PLASTIC DATABASE =====
const plasticDB = {
  PET: {
    name: 'PET Bottle / Container',
    full: 'Polyethylene Terephthalate',
    type: 'Type 1 — PET',
    emoji: '🥤',
    recyclable: 'Yes — widely accepted',
    recyclableClass: 'td-good',
    decompose: '450+ years',
    decomposeClass: 'td-bad',
    bin: 'Blue bin (plastic)',
    dropoff: '0.8 km away',
    risk: 'Low (single use), can leach antimony',
    alternatives: [
      { em: '🫙', name: 'Stainless steel bottle', desc: 'Lasts 10+ years, zero plastic waste' },
      { em: '🪨', name: 'Glass bottle', desc: '100% recyclable, no microplastics' },
      { em: '🧉', name: 'Clay/ceramic vessel', desc: 'Traditional Nepali doko-style, fully natural' },
    ],
  },
  HDPE: {
    name: 'HDPE Container',
    full: 'High-Density Polyethylene',
    type: 'Type 2 — HDPE',
    emoji: '🧴',
    recyclable: 'Yes — easy to recycle',
    recyclableClass: 'td-good',
    decompose: '100–500 years',
    decomposeClass: 'td-bad',
    bin: 'Blue bin (plastic)',
    dropoff: '1.2 km away',
    risk: 'Low, relatively stable',
    alternatives: [
      { em: '🪥', name: 'Bamboo alternatives', desc: 'For personal care products' },
      { em: '🍶', name: 'Glass containers', desc: 'For shampoo and liquids' },
    ],
  },
  PS: {
    name: 'Polystyrene (Styrofoam)',
    full: 'Polystyrene',
    type: 'Type 6 — PS',
    emoji: '📦',
    recyclable: 'No — avoid',
    recyclableClass: 'td-bad',
    decompose: '500+ years',
    decomposeClass: 'td-bad',
    bin: 'General waste (not recyclable)',
    dropoff: 'Specialist facility only',
    risk: 'High — styrene is a known carcinogen',
    alternatives: [
      { em: '🌿', name: 'Banana leaf packaging', desc: 'Traditional, biodegradable wrapping' },
      { em: '📋', name: 'Cardboard boxes', desc: 'Recyclable and biodegradable' },
      { em: '🪣', name: 'Reusable steel tiffin', desc: 'Perfect for Nepali street food takeaway' },
    ],
  },
  PVC: {
    name: 'PVC Pipe / Container',
    full: 'Polyvinyl Chloride',
    type: 'Type 3 — PVC',
    emoji: '🔧',
    recyclable: 'Rarely — complex process',
    recyclableClass: 'td-bad',
    decompose: '100–1000 years',
    decomposeClass: 'td-bad',
    bin: 'General waste',
    dropoff: 'N/A',
    risk: 'High — contains phthalates and chlorine',
    alternatives: [
      { em: '🪵', name: 'Bamboo pipes', desc: 'Traditional and sustainable material' },
      { em: '🔩', name: 'Steel pipes', desc: 'Long-lasting, fully recyclable' },
    ],
  },
  BAG: {
    name: 'Plastic Bag',
    full: 'Low-Density Polyethylene (LDPE)',
    type: 'Type 4 — LDPE',
    emoji: '🛍️',
    recyclable: 'Some — check store drop-offs',
    recyclableClass: 'td-bad',
    decompose: '10–1000 years',
    decomposeClass: 'td-bad',
    bin: 'Store drop-off only',
    dropoff: 'Bhatbhateni / Biratnagar',
    risk: 'Medium — breaks into microplastics',
    alternatives: [
      { em: '👜', name: 'Dhaka-fabric tote bag', desc: 'Handwoven Nepali traditional bag' },
      { em: '🛒', name: 'Jute bags', desc: 'Cheap, strong, fully biodegradable' },
      { em: '🎒', name: 'Reusable cloth bag', desc: 'Washable, foldable, zero waste' },
    ],
  },
};

// ===== PLASTIC TYPE GUIDE DATA =====
const plasticGuide = [
  { num: '1', name: 'PET (Polyethylene Terephthalate)', uses: 'Water bottles, food packaging, polyester fabric', bg: '#e8f7ef', tags: ['Recyclable ✔', '450yr decompose'], tagCls: ['tag-g', 'tag-a'] },
  { num: '2', name: 'HDPE (High-Density Polyethylene)', uses: 'Milk jugs, shampoo bottles, plastic pipes', bg: '#faeeda', tags: ['Easily recyclable ✔'], tagCls: ['tag-g'] },
  { num: '3', name: 'PVC (Polyvinyl Chloride)', uses: 'Pipes, window frames, cable insulation', bg: '#fcebeb', tags: ['Hard to recycle', 'Toxic when burned'], tagCls: ['tag-r', 'tag-r'] },
  { num: '4', name: 'LDPE (Low-Density Polyethylene)', uses: 'Plastic bags, squeeze bottles, film wrap', bg: '#faeeda', tags: ['Limited recycling', 'Microplastic risk'], tagCls: ['tag-a', 'tag-r'] },
  { num: '5', name: 'PP (Polypropylene)', uses: 'Bottle caps, food containers, straws', bg: '#e8f7ef', tags: ['Recyclable', 'Food-safe'], tagCls: ['tag-g', 'tag-g'] },
  { num: '6', name: 'PS (Polystyrene / Styrofoam)', uses: 'Cups, takeaway boxes, packaging foam', bg: '#fcebeb', tags: ['Avoid — not recyclable', 'Carcinogen risk'], tagCls: ['tag-r', 'tag-r'] },
  { num: '7', name: 'Other plastics (PC, ABS, etc.)', uses: 'Baby bottles, electronics, medical devices', bg: '#f1effe', tags: ['Avoid BPA plastic', 'Rarely recyclable'], tagCls: ['tag-r', 'tag-a'] },
];

// ===== LEADERBOARD DATA =====
const leaderboard = {
  nepal: [
    { init: 'RG', name: 'Rajan Gurung', pts: 4820, color: '#faeeda', tcolor: '#854f0b' },
    { init: 'PM', name: 'Priya Maharjan', pts: 4100, color: '#e8f7ef', tcolor: '#1a7a4a' },
    { init: 'SK', name: 'Sanjay KC', pts: 3670, color: '#e6f1fb', tcolor: '#185fa5' },
    { init: 'AT', name: 'Anita Tamang', pts: 3210, color: '#fbeaf0', tcolor: '#993556' },
    { init: 'BS', name: 'Bikram Shrestha', pts: 2980, color: '#faeeda', tcolor: '#854f0b' },
  ],
  ktm: [
    { init: 'PM', name: 'Priya Maharjan', pts: 4100, color: '#e8f7ef', tcolor: '#1a7a4a' },
    { init: 'AT', name: 'Anita Tamang', pts: 3210, color: '#fbeaf0', tcolor: '#993556' },
    { init: 'NB', name: 'Nabin Bajracharya', pts: 2450, color: '#e6f1fb', tcolor: '#185fa5' },
    { init: 'SP', name: 'Sunita Poudel', pts: 2100, color: '#faeeda', tcolor: '#854f0b' },
    { init: 'RM', name: 'Raj Magar', pts: 1950, color: '#e8f7ef', tcolor: '#1a7a4a' },
  ],
  global: [
    { init: 'AK', name: 'Aiko K. (Japan)', pts: 12400, color: '#fbeaf0', tcolor: '#993556' },
    { init: 'LM', name: 'Lena M. (Germany)', pts: 11200, color: '#e6f1fb', tcolor: '#185fa5' },
    { init: 'CM', name: 'Chidi M. (Nigeria)', pts: 9800, color: '#faeeda', tcolor: '#854f0b' },
    { init: 'VR', name: 'Vani R. (India)', pts: 8400, color: '#e8f7ef', tcolor: '#1a7a4a' },
    { init: 'RG', name: 'Rajan G. (Nepal)', pts: 4820, color: '#faeeda', tcolor: '#854f0b' },
  ],
};

// ===== UTILITIES =====
function $(id) { return document.getElementById(id); }
function showToast(msg, dur = 3000) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => { t.classList.add('hidden'); t.classList.remove('show'); }, dur);
}
function showLoading() { $('loading').classList.remove('hidden'); }
function hideLoading() { $('loading').classList.add('hidden'); }
function showModal(html) {
  $('modal-box').innerHTML = '<div class="modal-drag"></div>' + html;
  $('modal-overlay').classList.remove('hidden');
}
function closeModal() { $('modal-overlay').classList.add('hidden'); }
function addPoints(pts) {
  state.points += pts;
  $('nav-pts').textContent = `🌿 ${state.points.toLocaleString()} pts`;
  showToast(`🎉 +${pts} Eco Points earned!`);
  saveState();
}
function saveState() {
  try { localStorage.setItem('ecoscan_state', JSON.stringify({ points: state.points, scansCount: state.scansCount, plasticAvoided: state.plasticAvoided, streakDays: state.streakDays, scanHistory: state.scanHistory.slice(0, 20), joinedEvents: [...state.joinedEvents], likedStories: [...state.likedStories], challengeProgress: state.challengeProgress })); } catch(e) {}
}
function loadState() {
  try {
    const s = JSON.parse(localStorage.getItem('ecoscan_state') || '{}');
    if (s.points) state.points = s.points;
    if (s.scansCount) state.scansCount = s.scansCount;
    if (s.plasticAvoided) state.plasticAvoided = s.plasticAvoided;
    if (s.streakDays) state.streakDays = s.streakDays;
    if (s.scanHistory) state.scanHistory = s.scanHistory;
    if (s.joinedEvents) state.joinedEvents = new Set(s.joinedEvents);
    if (s.likedStories) state.likedStories = new Set(s.likedStories);
    if (s.challengeProgress) state.challengeProgress = { ...state.challengeProgress, ...s.challengeProgress };
  } catch(e) {}
}

// ===== AUTH =====
function signInWithGoogle() {
  showLoading();
  setTimeout(() => {
    hideLoading();
    state.user = { name: 'Eco Warrior', email: 'user@ecoscan.np', initials: 'EW', type: 'google' };
    bootApp();
  }, 1200);
}
function continueAsGuest() {
  state.user = { name: 'Guest User', email: 'guest@ecoscan.np', initials: 'G', type: 'guest' };
  bootApp();
}
function bootApp() {
  loadState();
  $('auth-screen').classList.remove('active');
  $('main-app').classList.remove('hidden');
  $('nav-avatar').textContent = state.user.initials;
  $('nav-pts').textContent = `🌿 ${state.points.toLocaleString()} pts`;
  navigate('home');
}

// ===== NAVIGATION =====
function navigate(tab) {
  state.currentTab = tab;
  document.querySelectorAll('.bn-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tab);
  });
  const content = $('page-content');
  content.scrollTop = 0;
  switch (tab) {
    case 'home': content.innerHTML = renderHome(); break;
    case 'scan': content.innerHTML = renderScan(); break;
    case 'learn': content.innerHTML = renderLearn(); break;
    case 'community': content.innerHTML = renderCommunity(); break;
    case 'rank': content.innerHTML = renderRank(); break;
  }
}

// ===== HOME PAGE =====
function renderHome() {
  const prog1 = Math.round((state.challengeProgress.plasticFree / 7) * 100);
  const prog2 = Math.round((state.challengeProgress.bagmati / 3) * 100);
  return `
  <div class="hero">
    <div class="hero-greet">Good morning,</div>
    <div class="hero-name">${state.user?.name || 'Eco Warrior'} 🌿</div>
    <div class="hero-cta">
      <button class="hero-btn" onclick="navigate('scan')">📷 Scan Plastic Now</button>
      ${state.streakDays > 0 ? `<div class="hero-streak">🔥 ${state.streakDays}-day streak</div>` : ''}
    </div>
    <div class="hero-stats">
      <div class="h-stat" onclick="navigate('scan')">
        <div class="h-stat-n">${state.scansCount}</div>
        <div class="h-stat-l">Items Scanned</div>
      </div>
      <div class="h-stat">
        <div class="h-stat-n">${state.plasticAvoided}kg</div>
        <div class="h-stat-l">Plastic Avoided</div>
      </div>
      <div class="h-stat" onclick="navigate('rank')">
        <div class="h-stat-n">${state.points.toLocaleString()}</div>
        <div class="h-stat-l">Eco Points</div>
      </div>
    </div>
  </div>
  <div class="section">
    <div class="sec-hdr"><div class="sec-title">Quick actions</div></div>
    <div class="qa-grid">
      <div class="qa-card" onclick="navigate('scan')">
        <div class="qa-ic" style="background:#e8f7ef">📷</div>
        <div class="qa-label">Scan Item</div>
        <div class="qa-sub">Identify plastic type instantly</div>
      </div>
      <div class="qa-card" onclick="navigate('learn')">
        <div class="qa-ic" style="background:#faeeda">📚</div>
        <div class="qa-label">Learn & Ask AI</div>
        <div class="qa-sub">Chat with EcoAI assistant</div>
      </div>
      <div class="qa-card" onclick="navigate('community')">
        <div class="qa-ic" style="background:#e6f1fb">🗺️</div>
        <div class="qa-label">Events Near You</div>
        <div class="qa-sub">Cleanup drives & workshops</div>
      </div>
      <div class="qa-card" onclick="navigate('rank')">
        <div class="qa-ic" style="background:#fbeaf0">🏆</div>
        <div class="qa-label">Leaderboard</div>
        <div class="qa-sub">See your Nepal ranking</div>
      </div>
    </div>
  </div>
  <div class="section" style="padding-top:0">
    <div class="sec-hdr">
      <div class="sec-title">Active challenges</div>
      <div class="sec-link" onclick="navigate('rank')">See all</div>
    </div>
    <div class="challenge-card" onclick="navigate('rank')">
      <div class="ch-em">🚫</div>
      <div class="ch-info">
        <div class="ch-title">Plastic-Free Week</div>
        <div class="ch-sub">Avoid single-use plastics for 7 days</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${prog1}%"></div></div>
        <div class="ch-meta">${state.challengeProgress.plasticFree} of 7 days completed · 200 pts reward</div>
      </div>
    </div>
    <div class="challenge-card" onclick="navigate('community')">
      <div class="ch-em">♻️</div>
      <div class="ch-info">
        <div class="ch-title">Bagmati River Guardian</div>
        <div class="ch-sub">Participate in 3 Bagmati cleanup events</div>
        <div class="progress-bar"><div class="progress-fill" style="width:${prog2}%"></div></div>
        <div class="ch-meta">${state.challengeProgress.bagmati} of 3 events attended · 500 pts reward</div>
      </div>
    </div>
  </div>
  <div class="section" style="padding-top:0">
    <div class="tip-card">🏔️ <strong>Nepal fact:</strong> The Bagmati River carries an estimated 35+ tonnes of plastic waste daily through Kathmandu before draining into the Ganges system and reaching the Bay of Bengal.</div>
    <div class="tip-card danger">⚠️ <strong>Health alert:</strong> Microplastics found in Kathmandu tap water. Filter or boil water stored in steel or clay vessels, not plastic containers.</div>
  </div>`;
}

// ===== SCAN PAGE =====
function renderScan() {
  const history = state.scanHistory.slice(0, 4).map(h => `
    <div class="scan-item" onclick="showScanResult('${h.key}')">
      <div class="scan-em">${h.emoji}</div>
      <div class="scan-info">
        <div class="scan-name">${h.name}</div>
        <div class="scan-meta">${h.date} · +${h.pts} pts</div>
      </div>
      <div class="scan-arrow">›</div>
    </div>`).join('');
  return `
  <div class="scan-page">
    <div class="page-header">
      <div class="page-title">Plastic Scanner</div>
      <div class="page-sub">Identify any plastic item and get recycling info</div>
    </div>
    <div class="scan-box">
      <div class="scan-target" id="scan-target" onclick="triggerScan()">
        <div class="scan-anim"></div>
        <div class="scan-ic">📷</div>
        <div class="scan-txt">Tap to identify item with AI</div>
      </div>
      <div class="divider">or identify manually</div>
      <div class="input-row">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#999" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input type="text" placeholder="Search: bottle, bag, container..." id="search-input" oninput="filterSearch(this.value)" />
        <button class="go-btn" onclick="doSearch()">Search</button>
      </div>
      <div id="search-results"></div>
    </div>
    <div id="scan-result-area"></div>
    ${state.scanHistory.length > 0 ? `
    <div class="recent-scans">
      <div class="sec-hdr" style="padding:0 0 0.5rem"><div class="sec-title">Recent scans</div></div>
      ${history}
    </div>` : ''}
  </div>`;
}

function filterSearch(val) {
  const container = document.getElementById('search-results');
  if (!val.trim()) { container.innerHTML = ''; return; }
  const v = val.toLowerCase();
  const matches = [];
  if ('bottle water pet'.includes(v) || v.includes('bottle') || v.includes('pet') || v.includes('water')) matches.push({ key: 'PET', ...plasticDB.PET });
  if ('hdpe shampoo milk container'.includes(v) || v.includes('shampoo') || v.includes('milk')) matches.push({ key: 'HDPE', ...plasticDB.HDPE });
  if ('bag plastic shopping'.includes(v) || v.includes('bag')) matches.push({ key: 'BAG', ...plasticDB.BAG });
  if ('styrofoam polystyrene cup foam'.includes(v) || v.includes('foam') || v.includes('cup') || v.includes('styro')) matches.push({ key: 'PS', ...plasticDB.PS });
  if ('pvc pipe'.includes(v) || v.includes('pipe') || v.includes('pvc')) matches.push({ key: 'PVC', ...plasticDB.PVC });
  if (!matches.length) { container.innerHTML = `<p style="font-size:12px;color:var(--txt3);text-align:center;margin-top:8px">No results — try "bottle", "bag", or "cup"</p>`; return; }
  container.innerHTML = matches.map(m => `
    <div class="scan-item" onclick="showScanResult('${m.key}')">
      <div class="scan-em">${m.emoji}</div>
      <div class="scan-info"><div class="scan-name">${m.name}</div><div class="scan-meta">${m.type}</div></div>
      <div class="scan-arrow">›</div>
    </div>`).join('');
}
function doSearch() {
  const v = document.getElementById('search-input')?.value;
  if (v) filterSearch(v);
}

function triggerScan() {
  const target = document.getElementById('scan-target');
  if (!target) return;
  target.classList.add('scanning');
  target.querySelector('.scan-txt').textContent = 'Analyzing with AI...';
  target.querySelector('.scan-ic').textContent = '🔍';
  // Simulate AI scan — pick a random plastic type
  const keys = Object.keys(plasticDB);
  const key = keys[Math.floor(Math.random() * keys.length)];
  setTimeout(() => {
    target.classList.remove('scanning');
    showScanResult(key);
  }, 2000);
}

function showScanResult(key) {
  const p = plasticDB[key];
  if (!p) return;
  // Record scan
  state.scansCount++;
  state.plasticAvoided = parseFloat((state.plasticAvoided + 0.05).toFixed(2));
  const pts = 15;
  const entry = { key, name: p.name, emoji: p.emoji, pts, date: new Date().toLocaleDateString('en-NP', { day: 'numeric', month: 'short' }) };
  state.scanHistory.unshift(entry);
  state.challengeProgress.scan10 = Math.min(state.challengeProgress.scan10 + 1, 10);
  addPoints(pts);
  saveState();
  // Update hero stat
  const heroStat = document.querySelector('.h-stat-n');
  if (heroStat) heroStat.textContent = state.scansCount;

  const alts = p.alternatives.map(a => `
    <div class="alt-row">
      <div class="alt-em">${a.em}</div>
      <div>
        <div class="alt-nm">${a.name}</div>
        <div class="alt-ds">${a.desc}</div>
      </div>
    </div>`).join('');
  const area = document.getElementById('scan-result-area');
  if (!area) return;
  area.innerHTML = `
    <div class="result-card">
      <div class="result-hdr">
        <div class="result-em">${p.emoji}</div>
        <div>
          <div class="result-nm">${p.name}</div>
          <div class="result-type">${p.full} · ${p.type}</div>
        </div>
      </div>
      <table class="info-table">
        <tr><td>Recyclable</td><td class="${p.recyclableClass}">${p.recyclable}</td></tr>
        <tr><td>Decomposition time</td><td class="${p.decomposeClass}">${p.decompose}</td></tr>
        <tr><td>Correct bin</td><td>${p.bin}</td></tr>
        <tr><td>Nearest drop-off</td><td class="td-good">${p.dropoff}</td></tr>
        <tr><td>Health risk</td><td>${p.risk}</td></tr>
      </table>
      <div class="alt-section">
        <div class="alt-title">♻️ Eco-friendly alternatives</div>
        ${alts}
      </div>
      <div class="points-earned">🎉 Scan recorded! +${pts} Eco Points earned</div>
    </div>`;
  area.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ===== LEARN PAGE =====
function renderLearn() {
  const types = plasticGuide.map(t => `
    <div class="plastic-type">
      <div class="pt-badge" style="background:${t.bg}">${t.num}</div>
      <div class="pt-info">
        <div class="pt-name">${t.name}</div>
        <div class="pt-uses">${t.uses}</div>
        <div class="tag-row">${t.tags.map((tg, i) => `<span class="tag ${t.tagCls[i]}">${tg}</span>`).join('')}</div>
      </div>
    </div>`).join('');
  return `
  <div class="learn-page">
    <div class="page-header">
      <div class="page-title">Learn & Educate</div>
      <div class="page-sub">Knowledge is the first step toward change</div>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="stat-num" style="color:#e24b4a">8M+</div><div class="stat-lbl">Tonnes of plastic entering oceans yearly</div></div>
      <div class="stat-card"><div class="stat-num" style="color:#ba7517">450</div><div class="stat-lbl">Years for a PET bottle to decompose</div></div>
      <div class="stat-card"><div class="stat-num">5T+</div><div class="stat-lbl">Microplastic pieces floating in oceans</div></div>
      <div class="stat-card"><div class="stat-num" style="color:var(--g)">91%</div><div class="stat-lbl">Of all plastic never recycled</div></div>
    </div>
    <div class="tip-card">🏔️ <strong>Nepal fact:</strong> The Bagmati River carries an estimated 35+ tonnes of plastic waste through Kathmandu daily. It flows into the Ganges system and ultimately deposits into the Bay of Bengal.</div>
    <div class="sec-hdr"><div class="sec-title">Plastic types guide</div></div>
    ${types}
    <div class="sec-hdr" style="margin-top:1.5rem"><div class="sec-title">Microplastic health risks</div></div>
    <div class="tip-card danger">⚠️ Microplastics have been detected in human blood, breast milk, and fetal tissue. Research suggests a person can ingest up to 5 grams of plastic per week — the equivalent of a credit card.</div>
    <div class="tip-card">💧 <strong>Water safety tip:</strong> Filter tap water in Kathmandu. The municipal supply often contains microplastic fragments from aging plastic pipes. Use a certified filter, or store in steel or clay vessels — not plastic containers.</div>
    <div class="tip-card warn">🌊 <strong>Food chain contamination:</strong> Fish caught near Kathmandu rivers show microplastic particles in their digestive tracts. The toxins accumulate up the food chain, eventually reaching humans.</div>
    <div class="sec-hdr" style="margin-top:1rem"><div class="sec-title">Ask EcoAI — your plastic advisor</div></div>
    <div class="ai-chat">
      <div class="ai-chat-hdr">
        <div class="ai-dot"></div>
        EcoAI — Powered by Claude AI
      </div>
      <div class="ai-messages" id="ai-messages">
        <div class="ai-msg bot"><div class="ai-bubble">Namaste! 🌿 I'm EcoAI, your plastic pollution advisor. Ask me anything about recycling, plastic types, the Bagmati River, or how to live more sustainably in Nepal!</div></div>
      </div>
      <div class="ai-input-row">
        <input class="ai-input" id="ai-input" type="text" placeholder="Ask about recycling, plastic types..." onkeydown="if(event.key==='Enter')sendAIMessage()" />
        <button class="ai-send" onclick="sendAIMessage()">Send</button>
      </div>
    </div>
  </div>`;
}

async function sendAIMessage() {
  const input = document.getElementById('ai-input');
  const msgs = document.getElementById('ai-messages');
  if (!input || !msgs) return;
  const text = input.value.trim();
  if (!text) return;
  input.value = '';

  // Add user message
  msgs.innerHTML += `<div class="ai-msg user"><div class="ai-bubble">${escapeHtml(text)}</div></div>`;

  // Add thinking indicator
  const thinkingId = 'thinking-' + Date.now();
  msgs.innerHTML += `<div class="ai-msg bot" id="${thinkingId}"><div class="ai-thinking"><span></span><span></span><span></span></div></div>`;
  msgs.scrollTop = msgs.scrollHeight;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: `You are EcoAI, a friendly and knowledgeable plastic pollution advisor inside the EcoScan app for Nepal. Your focus is on:
- Plastic pollution in Nepal, especially the Bagmati River in Kathmandu
- Recycling guidance specific to Nepal's waste management system
- Eco-friendly Nepali alternatives (dhaka bags, clay vessels, bamboo, etc.)
- Microplastic health risks for communities in South Asia
- How individuals in Kathmandu can reduce plastic use
Keep answers concise (2-4 sentences), warm, practical, and Nepal-specific where possible. Use occasional emojis. Always encourage positive action.`,
        messages: [{ role: 'user', content: text }]
      })
    });
    const data = await response.json();
    const reply = data.content?.[0]?.text || "I'm having trouble connecting. Please try again!";
    const thinkEl = document.getElementById(thinkingId);
    if (thinkEl) thinkEl.outerHTML = `<div class="ai-msg bot"><div class="ai-bubble">${escapeHtml(reply)}</div></div>`;
  } catch (err) {
    const thinkEl = document.getElementById(thinkingId);
    const fallback = getFallbackResponse(text);
    if (thinkEl) thinkEl.outerHTML = `<div class="ai-msg bot"><div class="ai-bubble">${escapeHtml(fallback)}</div></div>`;
  }
  msgs.scrollTop = msgs.scrollHeight;
  addPoints(5);
}

function getFallbackResponse(q) {
  const lq = q.toLowerCase();
  if (lq.includes('bagmati')) return '🏔️ The Bagmati River is one of Nepal\'s most sacred rivers, but it carries an estimated 35+ tonnes of plastic waste through Kathmandu daily. Community cleanup events happen every month — join one to make a real difference!';
  if (lq.includes('recycl')) return '♻️ In Kathmandu, PET (Type 1) and HDPE (Type 2) plastics are most widely recycled. Look for collection points at Bhatbhateni supermarkets or contact the Solid Waste Management Office at your municipality.';
  if (lq.includes('bag') || lq.includes('alternative')) return '🛍️ Swap plastic bags for Dhaka-fabric totes or jute bags — both are widely available in Nepal, long-lasting, and fully biodegradable. Many Kathmandu markets now offer them for under Rs 100!';
  if (lq.includes('microplastic') || lq.includes('health')) return '⚠️ Microplastics have been found in Kathmandu tap water and in fish from polluted rivers. Use a water filter, store water in steel or clay vessels, and avoid heating food in plastic containers.';
  return '🌿 Great question! Reducing plastic use in Nepal starts with simple swaps: cloth bags, steel water bottles, and supporting local businesses that use natural packaging. Every small action counts for the Bagmati and beyond!';
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/\n/g,'<br>');
}

// ===== COMMUNITY PAGE =====
function renderCommunity() {
  const events = [
    { id: 'ev1', day: '14', mon: 'APR', title: 'Bagmati River Cleanup Drive', loc: 'Tilganga, Pashupatinath Ghat · 7:00 AM', cnt: '45 volunteers registered · Free gloves & bags', pts: 300 },
    { id: 'ev2', day: '19', mon: 'APR', title: 'School Plastic Awareness Workshop', loc: 'Lalitpur Municipality Hall · 10:00 AM', cnt: 'For teachers & students · Certificate provided', pts: 150 },
    { id: 'ev3', day: '26', mon: 'APR', title: 'Eco Market — Plastic-Free Products Fair', loc: 'Asan Bazaar, Old Kathmandu · All day', cnt: '50+ vendors · Use Eco Points for discounts', pts: 100 },
    { id: 'ev4', day: '3', mon: 'MAY', title: 'World Press Freedom Cleanup — Kirtipur', loc: 'Kirtipur Municipality · 8:00 AM', cnt: 'Community initiative · All welcome', pts: 250 },
  ];
  const evHtml = events.map(e => {
    const joined = state.joinedEvents.has(e.id);
    return `<div class="event-card">
      <div class="ev-date"><div class="ev-day">${e.day}</div><div class="ev-mon">${e.mon}</div></div>
      <div class="ev-info">
        <div class="ev-title">${e.title}</div>
        <div class="ev-loc">📍 ${e.loc}</div>
        <div class="ev-cnt">${e.cnt}</div>
        <div class="ev-btn ${joined ? 'joined' : ''}" id="btn-${e.id}" onclick="${joined ? '' : `joinEvent('${e.id}', ${e.pts})`}">
          ${joined ? '✔ Registered' : `Join event → (+${e.pts} pts)`}
        </div>
      </div>
    </div>`;
  }).join('');

  const stories = [
    { id: 's1', init: 'SK', name: 'Sunita K.', loc: 'Patan', color: '#e8f7ef', tcolor: '#1a7a4a', text: 'I went plastic-free for 30 days — harder than I thought, but changing to cloth bags and steel tiffin made a huge difference. I stopped buying bottled water and started carrying my dhaka bag everywhere. The market vendors were supportive!', likes: 124 },
    { id: 's2', init: 'GT', name: 'Green KTM Team', loc: 'Kathmandu', color: '#e6f1fb', tcolor: '#185fa5', text: 'Before & after: last Sunday\'s Kirtipur drain cleanup removed over 80kg of plastic waste from just one drain section. Most of it was single-use packaging. Join us next time — the change is visible in days!', likes: 89 },
    { id: 's3', init: 'RM', name: 'Ram M.', loc: 'Bhaktapur', color: '#faeeda', tcolor: '#854f0b', text: 'Started a small composting + no-plastic initiative in our tole. 12 households joined. We now share jute bags, buy from local vegetable vendors who use leaf wrapping, and have reduced our plastic bin waste by 60%.', likes: 67 },
  ];
  const storiesHtml = stories.map(s => {
    const liked = state.likedStories.has(s.id);
    const lcount = liked ? s.likes + 1 : s.likes;
    return `<div class="story-card">
      <div class="story-hdr">
        <div class="story-avatar" style="background:${s.color};color:${s.tcolor}">${s.init}</div>
        <div><div class="story-name">${s.name}</div><div class="story-loc">📍 ${s.loc}</div></div>
      </div>
      <div class="story-text">${s.text}</div>
      <div class="story-actions">
        <div class="story-act ${liked ? 'liked' : ''}" id="like-${s.id}" onclick="toggleLike('${s.id}', ${s.likes})">
          ${liked ? '❤️' : '🤍'} ${lcount}
        </div>
        <div class="story-act">💬 Comment</div>
        <div class="story-act">📤 Share</div>
      </div>
    </div>`;
  }).join('');
  return `
  <div class="community-page">
    <div class="page-header">
      <div class="page-title">Community Hub</div>
      <div class="page-sub">Local events, cleanup drives & sustainability stories</div>
    </div>
    <div class="loc-banner">
      <div class="loc-pin">📍</div>
      <div>
        <div class="loc-name">Kathmandu, Bagmati Province</div>
        <div class="loc-sub">4 events this month · 8 volunteers active near you</div>
      </div>
    </div>
    <div class="sec-hdr"><div class="sec-title">Upcoming events</div></div>
    ${evHtml}
    <div class="sec-hdr" style="margin-top:0.5rem"><div class="sec-title">Community stories</div></div>
    ${storiesHtml}
    <div class="add-story" onclick="showAddStory()">
      <div class="add-story-txt">✍️ Share your eco story</div>
      <div class="add-story-sub">Inspire others in Nepal to take action</div>
    </div>
  </div>`;
}

function joinEvent(id, pts) {
  state.joinedEvents.add(id);
  state.challengeProgress.bagmati = Math.min(state.challengeProgress.bagmati + 1, 3);
  addPoints(pts);
  saveState();
  const btn = document.getElementById('btn-' + id);
  if (btn) { btn.textContent = '✔ Registered'; btn.classList.add('joined'); btn.onclick = null; }
}
function toggleLike(id, baseLikes) {
  const el = document.getElementById('like-' + id);
  if (!el) return;
  if (state.likedStories.has(id)) {
    state.likedStories.delete(id);
    el.innerHTML = `🤍 ${baseLikes}`;
    el.classList.remove('liked');
  } else {
    state.likedStories.add(id);
    el.innerHTML = `❤️ ${baseLikes + 1}`;
    el.classList.add('liked');
    addPoints(2);
  }
  saveState();
}
function showAddStory() {
  showModal(`
    <div style="padding:1.5rem">
      <div style="font-family:var(--font-display);font-size:20px;font-weight:700;color:var(--g);margin-bottom:1rem">Share your story</div>
      <textarea id="story-ta" placeholder="Tell the community about your eco journey in Nepal..." style="width:100%;height:120px;border:1px solid var(--border);border-radius:var(--r2);padding:12px;font-family:var(--font);font-size:13px;resize:none;background:var(--bg);color:var(--txt)"></textarea>
      <button onclick="submitStory()" style="width:100%;background:var(--g);color:#fff;font-size:14px;font-weight:700;padding:13px;border-radius:50px;margin-top:12px">Post Story (+20 pts)</button>
    </div>`);
}
function submitStory() {
  const val = document.getElementById('story-ta')?.value.trim();
  if (!val) { showToast('Please write your story first!'); return; }
  closeModal();
  addPoints(20);
  showToast('🌿 Your story has been shared with the community!');
}

// ===== RANK PAGE =====
let currentLBTab = 'nepal';
function renderRank() {
  return `
  <div class="rank-page">
    <div class="page-header">
      <div class="page-title">Eco Leaderboard</div>
      <div class="page-sub">Top plastic reducers in Nepal</div>
    </div>
    <div class="rank-hero">
      <div class="rank-medal">🏅</div>
      <div class="rank-info">
        <div class="rank-pos">#23 in Nepal</div>
        <div class="rank-sub">Top 5% this month!</div>
        <div class="rank-pts">🌿 ${state.points.toLocaleString()} Eco Points</div>
      </div>
    </div>
    <div class="tab-row">
      <div class="tab-btn ${currentLBTab==='nepal'?'active':''}" onclick="switchLBTab('nepal')">🇳🇵 Nepal</div>
      <div class="tab-btn ${currentLBTab==='ktm'?'active':''}" onclick="switchLBTab('ktm')">🏙️ Kathmandu</div>
      <div class="tab-btn ${currentLBTab==='global'?'active':''}" onclick="switchLBTab('global')">🌍 Global</div>
    </div>
    ${renderLBTable(currentLBTab)}
    <div class="sec-hdr" style="margin-top:1.5rem"><div class="sec-title">Ways to earn more points</div></div>
    <div class="earn-card"><div class="earn-em">📷</div><div class="earn-info"><div class="earn-title">Scan a plastic item</div><div class="earn-pts">+15 pts per scan</div></div><div class="earn-arrow">›</div></div>
    <div class="earn-card"><div class="earn-em">🤝</div><div class="earn-info"><div class="earn-title">Join a cleanup event</div><div class="earn-pts">+100–300 pts per event</div></div><div class="earn-arrow">›</div></div>
    <div class="earn-card"><div class="earn-em">💬</div><div class="earn-info"><div class="earn-title">Ask EcoAI a question</div><div class="earn-pts">+5 pts per question</div></div><div class="earn-arrow">›</div></div>
    <div class="earn-card"><div class="earn-em">✍️</div><div class="earn-info"><div class="earn-title">Share a story</div><div class="earn-pts">+20 pts per post</div></div><div class="earn-arrow">›</div></div>
    <div class="earn-card"><div class="earn-em">🚫</div><div class="earn-info">
      <div class="earn-title">Complete Plastic-Free Week</div>
      <div class="earn-pts">+200 pts bonus · ${state.challengeProgress.plasticFree}/7 days done</div>
      <div class="progress-bar" style="margin-top:6px"><div class="progress-fill" style="width:${Math.round(state.challengeProgress.plasticFree/7*100)}%"></div></div>
    </div></div>
    <div class="earn-card"><div class="earn-em">♻️</div><div class="earn-info">
      <div class="earn-title">Bagmati River Guardian</div>
      <div class="earn-pts">+500 pts bonus · ${state.challengeProgress.bagmati}/3 events attended</div>
      <div class="progress-bar" style="margin-top:6px"><div class="progress-fill" style="width:${Math.round(state.challengeProgress.bagmati/3*100)}%"></div></div>
    </div></div>
    <div style="margin-top:1.5rem;background:var(--gl);border-radius:var(--r);padding:1.25rem;text-align:center">
      <div style="font-size:14px;font-weight:600;color:var(--gd);margin-bottom:6px">🎁 Redeem Eco Points</div>
      <div style="font-size:12px;color:var(--txt2);line-height:1.5">Points are redeemable for discounts at partner eco-brands and local sustainable markets in Nepal. <span style="color:var(--g);font-weight:600;cursor:pointer" onclick="showToast('Marketplace coming soon — partner onboarding in progress!')">View marketplace →</span></div>
    </div>
  </div>`;
}
function renderLBTable(tab) {
  const rows = leaderboard[tab] || [];
  const medals = ['🥇','🥈','🥉'];
  const rowsHtml = rows.map((r, i) => `
    <div class="lb-row">
      <div class="lb-rank ${i<3?'top3':''}">${medals[i] || i+1}</div>
      <div class="lb-avatar" style="background:${r.color};color:${r.tcolor}">${r.init}</div>
      <div class="lb-name">${r.name}</div>
      <div class="lb-pts">${r.pts.toLocaleString()} pts</div>
    </div>`).join('');
  const meRow = `
    <div class="lb-row me">
      <div class="lb-rank top3">23</div>
      <div class="lb-avatar" style="background:var(--g);color:#fff">${state.user?.initials || 'ME'}</div>
      <div class="lb-name" style="font-weight:700">${state.user?.name || 'You'}</div>
      <div class="lb-pts">${state.points.toLocaleString()} pts</div>
    </div>`;
  return `<div class="lb-table">${rowsHtml}${meRow}</div>`;
}
function switchLBTab(tab) {
  currentLBTab = tab;
  document.querySelectorAll('.tab-btn').forEach((el, i) => {
    const tabs = ['nepal','ktm','global'];
    el.classList.toggle('active', tabs[i] === tab);
  });
  const table = document.querySelector('.lb-table');
  if (table) table.outerHTML = renderLBTable(tab);
}

// ===== PROFILE =====
function showProfile() {
  showModal(`
    <div class="profile-modal">
      <div class="modal-drag" style="margin-bottom:1.5rem"></div>
      <div class="profile-hdr">
        <div class="profile-avatar">${state.user?.initials || 'G'}</div>
        <div class="profile-name">${state.user?.name || 'Guest User'}</div>
        <div class="profile-email">${state.user?.email || ''}</div>
      </div>
      <div class="profile-stats">
        <div class="p-stat"><div class="p-stat-n">${state.points.toLocaleString()}</div><div class="p-stat-l">Eco Points</div></div>
        <div class="p-stat"><div class="p-stat-n">${state.scansCount}</div><div class="p-stat-l">Scans</div></div>
        <div class="p-stat"><div class="p-stat-n">${state.plasticAvoided}kg</div><div class="p-stat-l">Avoided</div></div>
      </div>
      <div class="profile-menu">
        <div class="pm-item" onclick="closeModal();showToast('Settings coming soon!')"><div class="pm-em">⚙️</div>Settings</div>
        <div class="pm-item" onclick="closeModal();showToast('Notifications on!')"><div class="pm-em">🔔</div>Notifications</div>
        <div class="pm-item" onclick="closeModal();navigate('rank')"><div class="pm-em">🏆</div>My achievements</div>
        <div class="pm-item" onclick="closeModal();showToast('Privacy policy opened.')"><div class="pm-em">🔒</div>Privacy policy</div>
        <div class="pm-item danger" onclick="signOut()"><div class="pm-em">🚪</div>Sign out</div>
      </div>
    </div>`);
}
function signOut() {
  closeModal();
  state.user = null;
  $('main-app').classList.add('hidden');
  $('auth-screen').classList.add('active');
}

// ===== PWA MANIFEST =====
window.addEventListener('load', () => {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
});

// ===== INIT =====
(function init() {
  // Check for returning user
  const saved = localStorage.getItem('ecoscan_user');
  if (saved) {
    try {
      state.user = JSON.parse(saved);
      bootApp();
      return;
    } catch(e) {}
  }
  // Otherwise show auth
  $('auth-screen').classList.add('active');
})();
