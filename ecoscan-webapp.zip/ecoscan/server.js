const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ===== PLASTIC DATABASE API =====
const plasticDB = {
  PET: { name: 'PET Bottle', full: 'Polyethylene Terephthalate', type: 'Type 1', recyclable: true, decompose: '450+ years', bin: 'Blue (plastic)', risk: 'Low', alternatives: ['Stainless steel bottle', 'Glass bottle', 'Clay vessel'] },
  HDPE: { name: 'HDPE Container', full: 'High-Density Polyethylene', type: 'Type 2', recyclable: true, decompose: '100-500 years', bin: 'Blue (plastic)', risk: 'Low', alternatives: ['Bamboo alternatives', 'Glass containers'] },
  PS: { name: 'Polystyrene', full: 'Polystyrene/Styrofoam', type: 'Type 6', recyclable: false, decompose: '500+ years', bin: 'General waste', risk: 'High — carcinogen', alternatives: ['Banana leaf', 'Cardboard', 'Steel tiffin'] },
  PVC: { name: 'PVC', full: 'Polyvinyl Chloride', type: 'Type 3', recyclable: false, decompose: '100-1000 years', bin: 'General waste', risk: 'High — chlorine compounds', alternatives: ['Bamboo pipes', 'Steel pipes'] },
  BAG: { name: 'Plastic Bag', full: 'Low-Density Polyethylene', type: 'Type 4', recyclable: false, decompose: '10-1000 years', bin: 'Store drop-off', risk: 'Medium — microplastics', alternatives: ['Dhaka tote bag', 'Jute bag', 'Cloth bag'] },
};

app.get('/api/plastic/:type', (req, res) => {
  const data = plasticDB[req.params.type.toUpperCase()];
  if (!data) return res.status(404).json({ error: 'Plastic type not found' });
  res.json(data);
});

app.get('/api/plastics', (req, res) => {
  res.json(Object.entries(plasticDB).map(([key, val]) => ({ key, ...val })));
});

// ===== EVENTS API =====
const events = [
  { id: 'ev1', title: 'Bagmati River Cleanup Drive', date: '2026-04-14', time: '7:00 AM', location: 'Tilganga, Pashupatinath Ghat', participants: 45, points: 300 },
  { id: 'ev2', title: 'School Plastic Awareness Workshop', date: '2026-04-19', time: '10:00 AM', location: 'Lalitpur Municipality Hall', participants: 28, points: 150 },
  { id: 'ev3', title: 'Eco Market — Plastic-Free Fair', date: '2026-04-26', time: 'All day', location: 'Asan Bazaar, Kathmandu', participants: 120, points: 100 },
];

app.get('/api/events', (req, res) => res.json(events));
app.post('/api/events/:id/join', (req, res) => {
  const ev = events.find(e => e.id === req.params.id);
  if (!ev) return res.status(404).json({ error: 'Event not found' });
  ev.participants++;
  res.json({ success: true, event: ev, pointsEarned: ev.points });
});

// ===== STATS API =====
app.get('/api/stats/nepal', (req, res) => {
  res.json({
    bagmatiPlasticTonnesDaily: 35,
    kathmandúPlasticGeneratedKgPerDay: 250000,
    recyclingRatePercent: 12,
    activeEcoScanUsers: 1842,
    totalScansThisMonth: 14200,
    plasticAvoidedKg: 3200,
  });
});

// ===== CATCH-ALL: Serve React/SPA =====
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🌿 EcoScan server running at http://localhost:${PORT}`);
});

module.exports = app;
